module.exports = {
  images: {
    domains: ['storage.googleapis.com']
  }
}